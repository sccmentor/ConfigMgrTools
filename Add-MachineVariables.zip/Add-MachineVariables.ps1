#   Notes 
#   Script name: Add-MachineVariables.ps1
#   Author:      Paul Winstanley
#   Contact:     @SCCMentor
#   DateCreated: 21/01/2015
#
#   Parameter variables description
#
#   $ComputerName = Hostname of computer to receive the Machine Variables
#   $SiteServer = ConfigMgr Site Server hostname
#   $SiteCode = ConfigMgr Site Code
#
#   Usage Example:
#   ./Add-MachineVariables.ps1 -ComputerName HostName-01 -SiteServer ConfigMgr-01 -SiteCode CMR 
#
#   $ComputerVariablesName & $ComputerVariablesValue arrays need to be completed below. Replace Name1, Name2 etc and Value1, Value2 with your 
#   required Machine Variables
#

param (
 [string]$ComputerName,
 [string]$SiteCode,
 [string]$SiteServer
 )

#Set Machine Variables Name and Value
$ComputerVariablesName  =  @("Name1", "Name2", "Name3", "Name4")
$ComputerVariablesValue = @("Value1", "Value2", "Value3", "Value4")


$MachineSettings = [WmiClass]"\\$SiteServer\ROOT\SMS\site_$($SiteCode):SMS_MachineSettings"
$ResourceID = (Get-WmiObject -ComputerName $SiteServer -Namespace root\SMS\Site_$($SiteCode) -Query "SELECT * FROM SMS_R_System where Name = '$ComputerName'").ResourceID
$objPCSet =  $MachineSettings.CreateInstance()
$objPCSet.psbase.properties["ResourceID"].value = $ResourceID
$objPCSet.psbase.properties["SourceSite"].value = $SiteCode


#Check that the number of Machine Variables type Name matches the number of Machine Variables type Value
if ($ComputerVariablesName.Count -eq $ComputerVariablesValue.Count) {  
for ($i = 0;$i -lt $ComputerVariablesName.Count; $i++)
{
   $objPCSet.MachineVariables = $objPCSet.MachineVariables + [WmiClass]"\\$SiteServer\ROOT\SMS\site_$($SiteCode):SMS_MachineVariable" 
}

# Get an array of the Variables
$MachineVariables =  $objPCSet.MachineVariables

# Set the Variables - Name and Value
# Loop for the amount of variables in $ComputerVariablesName
for ($i = 0;$i -lt $ComputerVariablesName.Count; $i++)
    {
    $MachineVariables[$i].name= $ComputerVariablesName[$i]
    $MachineVariables[$i].value= $ComputerVariablesValue[$i]
    }

$objPCSet.MachineVariables = $MachineVariables

# Store the variables
$objPCSet.put()
}
    else {
        Write-Host "The number of Machine Variables type Name and Value must match. Check your array."
        break
    }
